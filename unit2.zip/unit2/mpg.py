#!/usr/bin/env python3

# display a welcome message
print("The Miles Per Gallon application")
print()

# loop
choice = "y"
while choice.lower() == "y":

    # get input from the user
    miles_driven= float(input("Enter miles driven:\t"))
    gallons_used = float(input("Enter gallons of gas used:\t"))
    cost = float(input("Enter cost per gallon:\t"))


    if miles_driven <= 0:
        print("Miles driven must be greater than zero. Please try again.")
    elif gallons_used <= 0:
        print("Gallons used must be greater than zero. Please try again.")
    elif cost <= 0:
        print("Cost must be greater than zero. Please try again.")
    else:
        # calculate and display
        mpg = round((miles_driven / gallons_used), 2)
        total = gallons_used * cost
        total = round(total, 2)
        cpm = total / miles_driven
        cpm = round(cpm, 2)
        print()
        print("Miles Per Gallon:\t" + str(mpg))
        print()
        print("Total Cost:\t" + str(total))
        print()
        print("Cost Per Mile:\t" + str(cpm))

    # see if the user wants to continue
    choice = input("Continue (y/n)? ")
    print()

print()
print("Bye")



