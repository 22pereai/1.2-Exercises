#!/usr/bin/env python3

# display a welcome message
print("Welcome to the Future Value Calculator")
print()

choice = "y"
c1 = 0
c2 = 0
c3 = 0
while choice.lower() == "y":

    # get input from the user
    while c1 == 0:
        monthly_investment = float(input("Enter monthly investment:\t"))
        if monthly_investment < 1:
            print("Monthly Investment must be greater than 0. Try again.")
        else:
            c1 = 1
    while c2 == 0:
        yearly_interest_rate = float(input("Enter yearly interest rate:\t"))
        if yearly_interest_rate < 1:
            print("Yearly Interest Rate must be greater than 0. Try again.")
        elif yearly_interest_rate > 15:
            print("Yearly Interest Rate must be less than or equal to 15. Try again.")
        else:
            c2 = 1
    while c3 == 0:
        years = int(input("Enter number of years:\t\t"))
        if years < 1:
            print("Years must be greater than 0. Try again.")
        elif years > 50:
            print("Years must be less than or equal to 50. Try again.")
        else:
            c3 = 1

    # convert yearly values to monthly values
    monthly_interest_rate = yearly_interest_rate / 12 / 100
    months = years * 12

    # calculate the future value
    future_value = 0
    z = 1
    for i in range(months):
        future_value += monthly_investment
        monthly_interest_amount = future_value * monthly_interest_rate
        future_value += monthly_interest_amount
        if z >= 12:
            q = (i // 12) + 1
            print("Year:\t" + str(q) + " Future value:\t\t\t" + str(round(future_value, 2)))
            z = 1
        else:
            z = z + 1

    # display the result
    print("Future value:\t\t\t" + str(round(future_value, 2)))
    print()

    # see if the user wants to continue
    choice = input("Continue (y/n)? ")
    print()

print("Bye!")
